import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CustomerNotification {

    public static void main(String[] args) {
        // Code to initialize your Swing GUI

        JButton notifyCustomerButton = new JButton("Notify Customer");
        notifyCustomerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Code to send notification to the customer
                sendNotificationToCustomer();
            }
        });

        // Add the button to your GUI
    }

    private static void sendNotificationToCustomer() {
        // Code to send notification via email to the customer
        // You can use JavaMail API for this purpose
        // Example code (make sure to replace placeholders with actual values):
        String customerEmail = "customer@example.com";
        String subject = "Your Vehicle is Ready for Pickup";
        String message = "Dear Customer, Your vehicle is ready for pickup at Car Care.";

        EmailSender.sendEmail(customerEmail, subject, message);
    }
}
