public class EmployeeNotification {

    public static void main(String[] args) {
        // Code to initialize your Swing GUI

        JButton allocateJobButton = new JButton("Allocate Job");
        allocateJobButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Code to send notification to employees
                sendNotificationToEmployees();
            }
        });

        // Add the button to your GUI
    }

    private static void sendNotificationToEmployees() {
        // Code to send notification via email to the employees
        // You can use JavaMail API for this purpose
        // Example code (make sure to replace placeholders with actual values):
        String employeeEmail = "employee@example.com";
        String subject = "New Job Allocated";
        String message = "Dear Employee, a new job has been allocated to you at Car Care.";

        EmailSender.sendEmail(employeeEmail, subject, message);
    }
}
