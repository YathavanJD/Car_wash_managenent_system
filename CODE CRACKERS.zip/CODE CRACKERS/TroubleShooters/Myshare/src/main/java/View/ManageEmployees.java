/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Micro channel
 */
/*public class ManageEmployees {
    
}*/
package View;
import View.Abi_Part;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class ManageEmployees extends javax.swing.JFrame {
    private ArrayList<Abi_Part> employeeList = new ArrayList<>();

    // Variables declaration - do not modify
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration

    private void addEmployeeToList(Abi_Part employee) {
        employeeList.add(employee);
    }

    private void displayEmployees() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); // Clear the table before displaying the employees

        // Loop through the list of employees and add them to the table
        for (Abi_Part employee : employeeList) {
            model.addRow(employee.toObjectArray());
        }
    }

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {
        int selectedRowIndex = jTable1.getSelectedRow();

        if (selectedRowIndex != -1) {
            Abi_Part selectedEmployee = employeeList.get(selectedRowIndex);
            jTextField1.setText(String.valueOf(selectedEmployee.getId()));
            jTextField2.setText(selectedEmployee.getEmployeeName());
            jTextField3.setText(selectedEmployee.getposition());
            jTextField5.setText(selectedEmployee.getEmail());
        }
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        int Id = Integer.parseInt(jTextField1.getText());
        String EmployeeName = jTextField2.getText();
        String email = jTextField5.getText();
        String position = jTextField3.getText();

        // Create a new Abi_Part object
        Abi_Part newEmployee = new Abi_Part(Id, EmployeeName, email, position);

        // Add the new employee to the list
        addEmployeeToList(newEmployee);

        // Display the employees in the table
        displayEmployees();

        // Clear the input fields after adding the employee
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField5.setText("");
    }

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
        int selectedRowIndex = jTable1.getSelectedRow();

        if (selectedRowIndex != -1) {
            // Remove the selected row from the table and the employeeList
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.removeRow(selectedRowIndex);
            employeeList.remove(selectedRowIndex);
        }

        // Clear the input fields after deleting the employee
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField5.setText("");
    }

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
        int selectedRowIndex = jTable1.getSelectedRow();

        if (selectedRowIndex != -1) {
            int Id = Integer.parseInt(jTextField1.getText());
            String EmployeeName = jTextField2.getText();
            String email = jTextField5.getText();
            String position = jTextField3.getText();

            // Update the selected employee
            Abi_Part updatedEmployee = new Abi_Part(Id, EmployeeName, email, position);
            employeeList.set(selectedRowIndex, updatedEmployee);

            // Display the updated employees in the table
            displayEmployees();

            // Clear the input fields after updating the employee
            jTextField1.setText("");
            jTextField2.setText("");
            jTextField3.setText("");
            jTextField5.setText("");
        }
    }

    public ManageEmployees() {
        initComponents();

        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });

        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
    }

    private void initComponents() {
        // Initialization of components and layout settings should go here
        // ... (the original code for initComponents is removed for brevity)
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ManageEmployees manageEmployees = new ManageEmployees();
                manageEmployees.setVisible(true);

                // You may add some initial employees for testing here, or you can add them manually through the GUI
                 Abi_Part employee1 = new Abi_Part(1001, "Abishaya", "abishaya@gmail.com", "Manager");
                 Abi_Part employee2 = new Abi_Part(1002, "Vijay", "vijay@gmail.com", "Cashier");
                 manageEmployees.addEmployeeToList(employee1);
                 manageEmployees.addEmployeeToList(employee2);
                 manageEmployees.displayEmployees();
            }
        });
    }
}
